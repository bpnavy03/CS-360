package com.example.weighttrackingapplication_bryanpirrone;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        loginButton = findViewById(R.id.login_button);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    String username = usernameEditText.getText().toString();
                    String password = passwordEditText.getText().toString();

                    Log.d(TAG, "Login button clicked. Username: " + username + ", Password: " + password);

                    // Hardcoded credentials for testing
                    String hardcodedUsername = "testuser";
                    String hardcodedPassword = "testpassword";

                    if (username.equals(hardcodedUsername) && password.equals(hardcodedPassword)) {
                        Log.d(TAG, "Hardcoded login successful");
                        Intent intent = new Intent(MainActivity.this, DashboardActivity.class);
                        startActivity(intent);
                    } else {
                        Log.d(TAG, "Invalid username or password");
                        Toast.makeText(MainActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error during login", e);
                    Toast.makeText(MainActivity.this, "An error occurred during login", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}





