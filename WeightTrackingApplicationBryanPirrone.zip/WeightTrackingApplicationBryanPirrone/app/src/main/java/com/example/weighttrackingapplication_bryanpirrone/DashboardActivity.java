package com.example.weighttrackingapplication_bryanpirrone;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.widget.GridView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    private static final String TAG = "DashboardActivity";

    private GridView gridView;
    private DatabaseHelper dbHelper;
    private CustomCursorAdapter customCursorAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        try {
            Log.d(TAG, "DashboardActivity started");

            gridView = findViewById(R.id.grid_view);
            dbHelper = new DatabaseHelper(this);

            SQLiteDatabase db = dbHelper.getReadableDatabase();
            Cursor cursor = db.rawQuery("SELECT * FROM " + DatabaseHelper.TABLE_NAME, null);

            if (cursor != null) {
                Log.d(TAG, "Cursor not null, records found: " + cursor.getCount());
                customCursorAdapter = new CustomCursorAdapter(this, cursor);
                gridView.setAdapter(customCursorAdapter);
            } else {
                Log.d(TAG, "Cursor is null");
                Toast.makeText(this, "No data found", Toast.LENGTH_SHORT).show();
            }

            Log.d(TAG, "DashboardActivity setup complete");
        } catch (Exception e) {
            Log.e(TAG, "Error in DashboardActivity", e);
            runOnUiThread(() -> Toast.makeText(DashboardActivity.this, "An error occurred while loading the dashboard", Toast.LENGTH_SHORT).show());
        }
    }
}






